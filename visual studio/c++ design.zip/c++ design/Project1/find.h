#ifndef FIND_H
#define FIND_H
#include <string>
#include "book.h"
int isExist_Book(string title, Book_Data* book_data);
void Find_Book(string title, Book_Data* book_data);
#pragma once
#endif