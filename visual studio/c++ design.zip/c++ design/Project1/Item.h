#ifndef ITEM_H
#define ITEM_H

#include <string>
#define MAX 100
using namespace std;

class Item
{
protected:
    string ID;
    string Title;
    string Author;
    string Level;

public:
    Item(string id, string title, string author, string level)
        :ID(id), Title(title), Author(author), Level(level) {
    }
    void Get_Item(string id, string title, string author, string level);
    string Get_Title()
    {
        return Title;
    }
};

#endif // ITEM_H
#pragma once
