#include "delete.h"
#include "book.h"
void Delete_Books(string title,Book_Data* delete_book)
{
 	if(isExist_Book(title,delete_book)+1)
	{
		for(int i=isExist_Book(title,delete_book);i<MAX;i++)
		{
			if(i!=99)
			{
				//delete_book->books[i] = delete_book->books[i + 1];
			}	
		}
		delete_book->size--;
		cout<<"ɾ���ɹ�"<<endl; 
	}else
	{
		cout<<"���鲻����";	
	}
} 
