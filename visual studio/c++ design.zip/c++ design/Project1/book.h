#ifndef BOOK_H
#define BOOK_H

#include "Item.h"
#include <string>
#include <iostream>
#include <iomanip>
using namespace std;

class Book : public Item
{
public:
    friend istream& operator>>(istream&, Book& book);
    friend ostream& operator<<(ostream&, Book& book);
    Book() : Item("", "", "", ""), Publisher(""), IBSN(""), Page("") {} 
    Book(string id, string title, string author, string level, string publish, string ibsn, string page) :Item(id, title, author, level), Publisher(publish), IBSN(ibsn), Page(page) {}
    void Set(string id, string title, string author, string level, string publisher, string ibsn, string page);
    void Get();
private:
    string Publisher;
    string IBSN;
    string Page;
};

class Book_Note
{
public:
    Book book;
    Book_Note* next;
    Book_Note(Book b) : book(b), next(NULL) {}
};

class Book_Data {
public:
    int size = 0;
    Book_Note* head;
    Book_Note* p;
    Book_Note* tail;
    Book_Data() : head(NULL), p(NULL), tail(NULL) {} // 默认构造函数
    void Add_Book(Book &book)
    {
        Book_Note* newNode = new Book_Note(book);
        if (head == NULL)
        {
            head = newNode;
            tail = newNode;
        }
        else
        {
            tail->next = newNode;
            tail = newNode;
        }
        size++;
    }
    void Display_Book()
    {
        p = head;
        while (p != NULL)
        {
            cout << p->book << endl;
            p = p->next;
        }
    }
};

#endif // BOOK_H