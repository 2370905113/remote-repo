#include "find.h"

int isExist_Book(string title, Book_Data* exist_book)
{
	int  ret=-1;
	exist_book->p = exist_book->head;
	for (int i = 0; i < MAX; i++)
	{
		if (exist_book->p->book.Get_Title() == title)
		{
			ret = i;
		}
		else
		{
			ret = -1;
		}
	}
	return ret;
}
void Find_Book(string title, Book_Data* book_data)
{
	if (isExist_Book(title, book_data) + 1)
	{
		
	}
	else
	{
		cout << "δ��ѯ������" << endl;
	}
}
