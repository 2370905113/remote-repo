#include <windows.h>
#include <iostream>
using namespace std;
void Color_print(const char* s, int color); 
void Show_Menu_Main();
void Show_Menu_Book();