#include <iostream>
#include <string>
#include "book.h"
#include "Item.h"
#include "find.h"
#include "delete.h"
#include "menu.h"
#include <iomanip>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
class Video :public Item
{
public:
    Video() : Item("", "", "", ""), duration("") {}
    Video(string id, string title, string author, string level, string duration)
        : Item(id, title, author, level), duration(duration) {
    }
private:
    string Producer;
    string year;
    string duration;
};
class Picture :public Item
{
public:
    Picture() : Item("", "", "", ""), Nation(""), Length(0), Width(0) {}
    Picture(string id, string title, string author, string level, string nation, int length, int width)
        : Item(id, title, author, level), Nation(nation), Length(length), Width(width) {
    }
    string Nation;
    int Length;
    int Width;
};

Book_Data book_instance;
Book_Data* book_data = &book_instance;
Video videos[100]{};
Picture pictures[100]{};
int main()
{
    Show_Menu_Main();
    int Operation_ID;
    cout << "�������������" << endl;
    cin >> Operation_ID;
    cout << "\033[H\033[J";
    Show_Menu_Book();
    switch (Operation_ID)
    {
    case 0:
    {
        int class_choice = 1;
        while (class_choice)
        {
            cin >> class_choice;
            //Bookѡ��
            if (class_choice == 1)
            {
                Book temp;
                cin >> temp;
                book_instance.Add_Book(temp);
                book_instance.size++;
                cout << "\033[H\033[J";
                Show_Menu_Book();
            }
            else if (class_choice == 2)
            {
                //�鿴�洢��Ϣ 
                for (int i = 0; i < book_instance.size; i++)
                {
                    cout << "\033[H\033[J";
                    Show_Menu_Book();
                    book_instance.Display_Book();
                }
            }
            else if (class_choice == 3)
            {
                //��ѯ�鼮 
                cout << "\033[H\033[J";
                Show_Menu_Book();
                cout << "�������ѯ�鼮�ı���" << endl;
                string title;
                cin >> title;
                Find_Book(title, book_data);
            }
            else if (class_choice == 4)
            {
                //ɾ���鼮
                cout << "\033[H\033[J";
                Show_Menu_Book();
                cout << "��������Ҫɾ�����鼮" << endl;
                string title;
                cin >> title;
                Delete_Books(title, book_data);
            }
            else if (class_choice == 0)
            {
                cout << "\033[H\033[J";
                Show_Menu_Book();
                break;
            }
            else
            {
                cout << "\033[H\033[J";
                Show_Menu_Book();
                Color_print("����ѡ�����,����������\n", 70);
            }
        }
        break;
    }
    }
    system("pause");
    return 0;
}
