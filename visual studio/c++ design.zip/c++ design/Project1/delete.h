#ifndef DELETE_H
#define DELETE_H

#include "find.h"
#include "book.h"
void Delete_Books(string title, Book_Data* delete_book);
#pragma once

#endif